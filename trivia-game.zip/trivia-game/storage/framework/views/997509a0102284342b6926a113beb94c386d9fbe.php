    
    <?php $__env->startSection('title'); ?>
        Question Ans Text After Play
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

        <div id="content">

            <?php if(Session::has('success')): ?>
            <div class="row" id="success">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-success">
                        <a class="close" data-dismiss="alert">×</a>
                        <?php echo Session::get('success'); ?>

                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
            <div class="row" id="success">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" role="alert">
                        <a class="close" data-dismiss="alert">×</a>
                        <?php echo Session::get('error'); ?>

                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class='qtDiv'>

                <div class="qtDate"><?php echo e($answerResults->created_at->format('m/d/y')); ?> </div>

                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <br>

                <p style="margin-bottom: 30px;margin-top: 15px; font-weight: bold;">
                    <?php echo e($questionResults->text); ?>

                </p>

                <div class='ansDiv'>
                    <div class='ansLeftCol'><div class='ansNumber'><?php echo e($answerResults->ans_number); ?></div>19%</div>
                    <div class='ansText'><?php echo e($answerResults->ans_text); ?></div>
                </div>

                <?php echo e(Form::open(array('url' => 'user-answer','method' => 'post','class'=>'form-inner','id'=>'formAnswerInsert', 'enctype'=>'multipart/form-data' ))); ?>


                    <?php if( Auth::user()->id == $questionResults->user_id  ): ?>
                        <textarea  id="frmUserAns" class="inputFieldText" placeholder="Add Text" name="frmUserAns" cols="50" rows="10" disabled></textarea>
                    <?php else: ?>
                        <?php echo e(Form::textarea('frmUserAns', old('frmUserAns'),['id' => 'frmUserAns','class' => 'inputFieldText','placeholder' => 'Add Text'])); ?><br>
                    <?php endif; ?>  

                    <?php if($errors->has('frmUserAns')): ?>
                        <span class="invalid-feedback" role="alert" style="display:block;">
                            <strong><?php echo e($errors->first('frmUserAns')); ?></strong>
                        </span> <br/>
                    <?php endif; ?>

                    <input type="hidden" name="questionID" value="<?php echo e($questionResults->id); ?>">
                    <input type="hidden" name="answerID" value="<?php echo e($answerResults->id); ?>">
                    <input type="hidden" name="userID" value="<?php echo e($questionResults->user_id); ?>">

                    <input type="submit" value="SAVE" class="submitButton" style="border: none; font-size: 18px;"  <?php echo e(( Auth::user()->id == $questionResults->user_id  ) ? 'disabled' : ''); ?>/>
               <?php echo e(Form::close()); ?>

                
            </div>

        </div><!-- end content -->
        
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function(){

                setTimeout(function(){  
                    $("#success").hide(); 
                }, 8000);

                $('#formAnswerInsert').validate({ 
                    rules: {
                        frmUserAns: {
                            required: true,
                            minlength: 10,
                            maxlength: 500,
                            //lettersonly: true,
                        },
                    }, 
                    messages: {
                        
                    }   
                });

            });
        </script>        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>