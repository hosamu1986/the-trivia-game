    
    <?php $__env->startSection('title'); ?>
        Question Details
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div id="content">
            <!-- success message -->
            <div class="row" style="width: 90%;">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" style="display:none"></div>
                    <div class="alert alert-success d-none" id="msg_div">
                        <span id="res_message"></span>
                    </div>
                </div>
            </div>

            <div class='qtDiv'>
                <div class="qtDate"><?php echo e($results->created_at->format('m/d/y')); ?></div>
                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <?php if(!Auth::guest()): ?>
                    <?php if($results->user_id == Auth::id()): ?>
                        <a href="javascript:;">
                            <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                        </a>
                    <?php else: ?>
                        <a href="javascript:;" data-id="<?php echo e($results->id); ?>" id="red-flag">
                            <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="javascript:;">
                        <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                    </a>
                <?php endif; ?>
                <p style="margin-bottom: 30px;margin-top: 15px; font-weight: bold;"><?php echo e($results->text); ?></p>
                <?php if( isset($answers) ): ?>
                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        

                      

                        <div class='ansDiv'>
                            <div class='ansLeftCol'><div class='ansNumber'><?php echo e($value->ans_number); ?></div>19%</div>
                            <div class='ansText'><?php echo e($value->ans_text); ?></div>

                            <?php if( Auth::check()  &&  Auth::user()->id != $results->user_id ): ?>
                                <?php if($value->getSingleAnswerText($results->id,$value->id)): ?>
                                    <div class='voteTextsDim'>PLAY</div>
                                <?php else: ?>
                                    <a href="<?php echo e(route('qt.ans.text.after.play',$value->id)); ?>"><div class='voteTexts'>PLAY</div></a> 
                                <?php endif; ?>
                                
                            <?php else: ?>
                                <div class='voteTextsDim'>PLAY</div>
                            <?php endif; ?>

                            <a href="<?php echo e(route('question.ans.text',$value->id)); ?>"><div class='voteTexts'>TEXTS</div></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>

            <div id="flag" class="pop-up-div-ex3" style="display:none; z-index:100;">
                <input type="button" class="closeSquare" value="X" onclick="$('#flag').fadeOut('slow')" />
                <h2>Content Flag</h2>
                <p id="question"><?php echo e($results->text); ?></p>
                <p>Thank you for your help.</p>
                <input type="submit" value="Flag Content" class="submitButton" style="width: 120px !important;">
            </div>

        </div><!-- end content -->
        
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#red-flag").click(function(){
                    $('#msg_div').addClass('d-none');
                    $('#msg_div').show();
                    var questionId = $(this).attr("data-id");
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url:"<?php echo e(url('question-flag')); ?>",  
                        method:"POST", 
                        data: { id: questionId },
                        success: function(response)
                        {
                            console.log(response);
                            //$('#something').html(response);
                            /*$('#res_message').show();
                            $('#res_message').html(response.msg);
                            $('#msg_div').removeClass('d-none');*/
                            $("#flag").show();
                            /*setTimeout(function(){
                                $('#res_message').hide();
                                $('#msg_div').hide();
                            },3000);*/
                            jQuery.each(response.errors, function(key, value){
                                $('#msg_div').hide();
                                $('.alert-danger').show();
                                $('.alert-danger').append('<p>'+value+'</p>');
                            });
                        }
                    });
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>