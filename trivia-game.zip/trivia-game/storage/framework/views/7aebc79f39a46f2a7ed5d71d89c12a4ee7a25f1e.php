	<header>
		<div class="profileLogo" style="margin-bottom: 15px; margin-top: 15px;"> 
			<!-- Profile logo. Add a img tag in place of <span>. -->
			<p class="logoPlaceholder">
				<a href="<?php echo e(url('/')); ?>">
					<img src="<?php echo e(asset('images/theTriviaGame-logo.png')); ?>" width="416" height="74" alt=""/>
				</a>
			</p>
		</div>
	
		<div class="row">
			<div class="col-md-8 offset-md-1 pl-0 pr-0">
				<div class="row">
						<div class="col-md-8 pr-0 pl-5">
							
							<?php if(auth()->guard()->guest()): ?>
							<div class="row">
								<div class="col-md-8 pr-0">
								<?php echo e(Form::open(array('url' => 'login','method' => 'post','class'=>'form-inner','id'=>'frmlogin', 'enctype'=>'multipart/form-data' ))); ?> 
									<input id="login" type="text" class="inputField <?php echo e($errors->has('username') || $errors->has('email') ? ' is-invalid' : ''); ?>" name="login" value="<?php echo e(old('username') ?: old('email')); ?>" placeholder="username" required autofocus />
									
		                            <input id="password" type="password" class="inputField <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="password" required>
		                            <?php if($errors->has('password')): ?>
		                                <span class="invalid-feedback" role="alert">
		                                    <strong><?php echo e($errors->first('password')); ?></strong>
		                                </span>
		                            <?php endif; ?>
		                            <input type="submit" name="submit" style="display: none;" />
								<?php echo e(Form::close()); ?>


								</div>
								<div class="col-md-4 pl-0 text-left">
						            <a href="<?php echo e(route('register')); ?>" style="font-size: 13px; color: #000;">Sign in</a> /
									<a href="<?php echo e(route('login')); ?>" style="font-size: 13px; color: #000;">Login</a> /
								</div>
							</div>
					        <?php else: ?>
					            <span style="font-size: 18px;"><strong>Hi <?php echo e(Auth::user()->username); ?>  <!-- <?php echo e(Auth::user()->created_at->toTimeString()); ?> --></strong>,</span> &nbsp;&nbsp;&nbsp;&nbsp;
				                <a style="font-size: 13px; color: #000;" href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
				                    <?php echo e(__('Logout')); ?>

				                </a>
				                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
				                    <?php echo csrf_field(); ?>
				                </form>
					        <?php endif; ?>
					        
				       	</div>
			        	<div class="col-md-4 pl-0 text-left">
			        		<?php $currentRouteName = Route::currentRouteName(); ?>
			        		<?php if( $currentRouteName == 'questions' ): ?>
			        			Your Ranking: <strong><?php echo e(Auth::user()->points); ?></strong>&nbsp;/
			        		<?php else: ?>
			        			<?php if(!Auth::guest()): ?>
				        			<a href="<?php echo e(route('questions')); ?>" style="font-size: 14px; color: #000;">Your Questions</a>&nbsp;/
				        		<?php endif; ?>
			        		<?php endif; ?>
			        		
							<a href="<?php echo e(url('about')); ?>" style="font-size: 13px; color: #000;">About</a> &nbsp;/&nbsp; 
							<a href="#"> <img src="<?php echo e(asset('images/Search-20.png')); ?>" style="width: 16px; height: auto;" alt=""/> </a>
						</div>
						<div class="col-md-12 offset-md-2 text-left">
							<?php if($errors->has('username') || $errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert" style="display: block;">
                                    <strong><?php echo e($errors->first('username') ?: $errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
				</div>	
			</div>
		</div>

	</header>