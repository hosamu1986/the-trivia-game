    
    <?php $__env->startSection('title'); ?>
        Question Ans Details
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>


        <div id="content">
            <!-- success message -->
            <div class="row" style="width: 90%;">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" style="display:none"></div>
                    <div class="alert alert-success d-none" id="msg_div">
                        <span id="res_message"></span>
                    </div>
                </div>
            </div>

            <div class='qtDiv'>

                <div class="qtDate"><?php echo e($answerResults->created_at->format('m/d/y')); ?> <!-- 8/19/19  --></div>

                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <br>

                <p style="margin-bottom: 30px;margin-top: 15px; font-weight: bold;">
                    <?php echo e($questionResults->text); ?>

                </p>

                <div class='ansDiv'>
                    <div class='ansLeftCol'><div class='ansNumber'><?php echo e($answerResults->ans_number); ?></div>19%</div>
                    <div class='ansText'><?php echo e($answerResults->ans_text); ?></div>
                </div>

                <div class="ansTexts">

                    <?php if( isset($textResults) ): ?>
                        <?php $__currentLoopData = $textResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="textOfAns">
                                <?php echo e($value->user_text); ?> <br>
                                <?php if(!Auth::guest()): ?>
                                    <?php if($value->user_id == Auth::id()): ?>
                                        <a href="javascript:;">
                                            <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                                        </a>
                                    <?php else: ?>
                                        <a href="javascript:;" data-id="<?php echo e($value->id); ?>" id="red-flag">
                                            <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                                        </a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <a href="javascript:;">
                                        <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                                    </a>
                                <?php endif; ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>





                    <!-- <div class="textOfAns">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<Br>
                    <a href="#"><img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/></a>
                    </div>

                    <div class="textOfAns">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br>
                    <a href="#"><img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/></a>
                    </div>

                    <div class="textOfAns">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<Br>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br>
                    <a href="#"><img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/></a>
                    </div> -->

                </div>
            </div>

        </div><!-- end content -->


        <!--  -->
        
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#red-flag").click(function(){
                    $('#msg_div').addClass('d-none');
                    $('#msg_div').show();
                    var questionId = $(this).attr("data-id");
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url:"<?php echo e(url('text-flag')); ?>",  
                        method:"POST", 
                        data: { id: questionId },
                        success: function(response)
                        {
                            console.log(response);
                            //$('#something').html(response);
                            $('#res_message').show();
                            $('#res_message').html(response.msg);
                            $('#msg_div').removeClass('d-none');
                            setTimeout(function(){
                                $('#res_message').hide();
                                $('#msg_div').hide();
                            },3000);
                            jQuery.each(response.errors, function(key, value){
                                $('#msg_div').hide();
                                $('.alert-danger').show();
                                $('.alert-danger').append('<p>'+value+'</p>');
                            });
                        }
                    });
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>