    
    <?php $__env->startSection('title'); ?>
        Your Question Ans Text
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>


        <div id="content">

            <!-- success message -->
            <div class="row" style="width: 90%;">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" style="display:none"></div>
                    <div class="alert alert-success d-none" id="msg_div">
                        <span id="res_message"></span>
                    </div>
                </div>
            </div>

            <div class='qtDiv'>

                <div class="qtDate"><?php echo e($userAnswerResults->question->created_at->format('m/d/y')); ?> </div>

                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <br>

                <p style="margin-bottom: 30px;margin-top: 15px; font-weight: bold;">
                    <?php echo e($userAnswerResults->question->text); ?>

                </p>

                <div class='ansDiv'>
                    <div class='ansLeftCol'><div class='ansNumber'><?php echo e($userAnswerResults->answer->ans_number); ?></div>19%</div>
                    <div class='ansText'><?php echo e($userAnswerResults->answer->ans_text); ?></div>
                </div>

                <div class="ansTexts">                    
                    <div class="textOfAns">
                        <strong><?php echo e($userAnswerResults->user_text); ?></strong>
                        <p style="text-align: center;">Rate text? (optional)&nbsp;&nbsp;
                            <?php if(!Auth::guest()): ?>
                                <?php if($userAnswerResults->user_id == Auth::id()): ?>
                                    <a href="javascript:;">
                                        <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                                    </a>
                                <?php else: ?>
                                    <a href="javascript:;" data-id="<?php echo e($userAnswerResults->id); ?>" id="red-flag">
                                        <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                                    </a>
                                <?php endif; ?>
                            <?php else: ?>
                                <a href="javascript:;">
                                    <img src="<?php echo e(asset('images/red-flag.png')); ?>" width="18" height="18" alt=""/>
                                </a>
                            <?php endif; ?>
                        </p>

                        <?php if(!Auth::guest()): ?>
                            <?php if($userAnswerResults->user_id == Auth::id()): ?>  
                                <div class='rateTexts'>+1</div>
                                <div class='rateTexts'>+2</div>
                                <div class='rateTexts'>+3</div>
                                <div class='rateTexts'>+4</div>
                                <div class='rateTexts'>+5</div>
                            <?php else: ?>
                                <a href="javascript:;" data-id="<?php echo e($userAnswerResults->id); ?>" data-points="1" data-userid="<?php echo e($userAnswerResults->user_id); ?>" class="userPoints">
                                    <div class='rateTexts'>+1</div>
                                </a>
                                <a href="javascript:;" data-id="<?php echo e($userAnswerResults->id); ?>" data-points="2" data-userid="<?php echo e($userAnswerResults->user_id); ?>" class="userPoints">
                                    <div class='rateTexts'>+2</div>
                                </a>
                                <a href="javascript:;" data-id="<?php echo e($userAnswerResults->id); ?>" data-points="3" data-userid="<?php echo e($userAnswerResults->user_id); ?>" class="userPoints">
                                    <div class='rateTexts'>+3</div>
                                </a>
                                <a href="javascript:;" data-id="<?php echo e($userAnswerResults->id); ?>" data-points="4" data-userid="<?php echo e($userAnswerResults->user_id); ?>" class="userPoints">
                                    <div class='rateTexts'>+4</div>
                                </a>
                                <a href="javascript:;" data-id="<?php echo e($userAnswerResults->id); ?>" data-points="5" data-userid="<?php echo e($userAnswerResults->user_id); ?>" class="userPoints">
                                    <div class='rateTexts'>+5</div>
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class='rateTexts'>+1</div>
                            <div class='rateTexts'>+2</div>
                            <div class='rateTexts'>+3</div>
                            <div class='rateTexts'>+4</div>
                            <div class='rateTexts'>+5</div>
                        <?php endif; ?>

                    </div>
                </div>

            </div>

        </div><!-- end content -->
        
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function(){
                $(".userPoints").click(function(){
                    $('#msg_div').addClass('d-none');
                    $('#msg_div').show();
                    var ans_text_id = $(this).attr("data-id");
                    var points = $(this).attr("data-points");
                    var userid = $(this).attr("data-userid");
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url:"<?php echo e(url('user-point')); ?>",  
                        method:"POST", 
                        data: { id: ans_text_id,points: points,user_id:userid },
                        success: function(response)
                        {
                            console.log(response);
                            //$('#something').html(response);
                            $('#res_message').show();
                            $('#res_message').html(response.msg);
                            $('#msg_div').removeClass('d-none');
                            setTimeout(function(){
                                $('#res_message').hide();
                                $('#msg_div').hide();
                            },3000);
                            jQuery.each(response.errors, function(key, value){
                                $('#msg_div').hide();
                                $('.alert-danger').show();
                                $('.alert-danger').append('<p>'+value+'</p>');
                            });
                        }
                    });
                });
            });
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                $("#red-flag").click(function(){
                    $('#msg_div').addClass('d-none');
                    $('#msg_div').show();
                    var questionId = $(this).attr("data-id");
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url:"<?php echo e(url('text-flag')); ?>",  
                        method:"POST", 
                        data: { id: questionId },
                        success: function(response)
                        {
                            console.log(response);
                            //$('#something').html(response);
                            $('#res_message').show();
                            $('#res_message').html(response.msg);
                            $('#msg_div').removeClass('d-none');
                            setTimeout(function(){
                                $('#res_message').hide();
                                $('#msg_div').hide();
                            },3000);
                            jQuery.each(response.errors, function(key, value){
                                $('#msg_div').hide();
                                $('.alert-danger').show();
                                $('.alert-danger').append('<p>'+value+'</p>');
                            });
                        }
                    });
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>