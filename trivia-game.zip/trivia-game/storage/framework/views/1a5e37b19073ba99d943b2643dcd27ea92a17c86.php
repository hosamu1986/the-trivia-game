    
    <?php $__env->startSection('title'); ?>
        New Question & Answers
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('style'); ?>
        <style type="text/css">
            .qtDiv{ padding: 10px; }
            .alert.alert-danger li {list-style: none; }
        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div id="content">
        <h2>New Question &amp; Answers</h2>
            You must enter at least two answers<br /><br>

        <?php if(Session::has('success')): ?>
        <div class="row" id="success">
            <div class="col-md-6 offset-md-3">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert">×</a>
                    <?php echo Session::get('success'); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div><br />
                </div>
            </div> 
        <?php endif; ?>

        <?php echo e(Form::open(array('route' => ['update.your.new.qt.sb',$questionResults->id],'method' => 'post','class'=>'form-inner','id'=>'formQuestionInsert','name'=>'formQuestionInsert' ))); ?>

            <?php echo e(Form::hidden('frmQuestionId', @$questionResults->id,['id' => 'frmQuestionId','class' => 'qtDiv'])); ?>

            <?php echo e(Form::textarea('frmQuestion', @$questionResults->text,['id' => 'frmQuestion','class' => 'qtDiv','placeholder' => 'Your Question','rows'=>'2'])); ?> <br>
            <?php echo e(Form::textarea('frmQuestionAnser1', @$questionResults->answers[0]->ans_text,['id' => 'frmQuestionAnser1','class' => 'qtDiv','placeholder' => 'Answer 1','rows'=>'2'])); ?> <br>
            <?php echo e(Form::textarea('frmQuestionAnser2', @$questionResults->answers[1]->ans_text,['id' => 'frmQuestionAnser2','class' => 'qtDiv','placeholder' => 'Answer 2','rows'=>'2'])); ?> <br>
            <?php echo e(Form::textarea('frmQuestionAnser3', @$questionResults->answers[2]->ans_text,['id' => 'frmQuestionAnser3','class' => 'qtDiv','placeholder' => 'Answer 3 (optional)','rows'=>'2'])); ?> <br>
            <?php echo e(Form::textarea('frmQuestionAnser4', @$questionResults->answers[3]->ans_text,['id' => 'frmQuestionAnser4','class' => 'qtDiv','placeholder' => 'Answer 4 (optional)','rows'=>'2'])); ?> <br>
            <input type="submit" value="Save your trivia" class="submitButton" style="width: 160px !important; font-size: 18px;">
        <?php echo e(Form::close()); ?>


        <div id="snowball" class="pop-up-div-ex3" style="display:none; z-index:100;" >
            <input type="button" class="closeSquare" value="X" onclick="$('#snowball').fadeOut('slow')" />
            <h2>Save your trivia</h2>
            <p> Save your trivia question on<br> Your computer<br> Get your internet address<br> For this question<Br> (URL) </p>
            <p><a href="javascript:;" id="qturl">http://the-trivia-game.com/id=2033</a></p>
            <!-- <input type="submit" value="Copy text and link" class="submitButton" style="width: 151px !important;"> -->
            <input type="submit" value="Copy text and link" id="submitButton" class="submitButton" style="width: 151px !important;">
        </div>

        <p style="margin-top: 15px;"><strong>Note:</strong>  Save the internet link of your trivia question. You never know…</p>
    </div><!-- end content -->
    
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script src="<?php echo e(asset('js/jquery.copy-to-clipboard.js')); ?>"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#submitButton').click(function(){
                    $("#qturl").CopyToClipboard();
                });

                setTimeout(function(){  
                    $("#success").hide(); 
                }, 8000);

                $('#formQuestionInsert').validate({ 
                    rules: {
                        frmQuestion: {
                            required: true,
                            minlength: 10,
                        },
                        frmQuestionAnser1: {
                            required: true,
                            minlength: 10,
                        },
                        frmQuestionAnser2: {
                            required: true,
                            minlength: 10,
                        },
                        frmQuestionAnser3: {
                            minlength: 10,
                        },
                        frmQuestionAnser4: {
                            minlength: 10,
                        },
                    }, 
                    messages: {
                        
                    },
                   submitHandler: function(form) {
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            url:"<?php echo e(route('update.your.new.qt.sb',$questionResults->id)); ?>",  
                            method:"POST", 
                            data: $('form').serialize(),
                            success: function(response)
                            {
                                $("#snowball").show();
                                $('#qturl').text(response.msg);
                            }
                        });
                    } 
                });
            });
        </script>
        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>