    
    <?php $__env->startSection('title'); ?>
        New Question & Answers
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('style'); ?>
        <style type="text/css">
            .qtDiv{ padding: 10px; }
            .alert.alert-danger li {list-style: none; }
        </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div id="content">
        <h2>New Question &amp; Answers</h2>
            You must enter at least two answers<br /><br>

        <?php if(Session::has('success')): ?>
        <div class="row" id="success">
            <div class="col-md-6 offset-md-3">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert">×</a>
                    <?php echo Session::get('success'); ?>

                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div><br />
                </div>
            </div> 
        <?php endif; ?>

        <?php echo e(Form::open(array('url' => 'your-new-question','method' => 'post','class'=>'form-inner','id'=>'formQuestionInsert', 'enctype'=>'multipart/form-data' ))); ?>


            <?php echo e(Form::textarea('frmQuestion', old('frmQuestion'),['id' => 'frmQuestion','class' => 'qtDiv','placeholder' => 'Your Question','rows'=>'2'])); ?> <br>

            <?php echo e(Form::textarea('frmQuestionAnser1', old('frmQuestionAnser1'),['id' => 'frmQuestionAnser1','class' => 'qtDiv','placeholder' => 'Answer 1','rows'=>'2'])); ?> <br>


            <?php echo e(Form::textarea('frmQuestionAnser2', old('frmQuestionAnser2'),['id' => 'frmQuestionAnser2','class' => 'qtDiv','placeholder' => 'Answer 2','rows'=>'2'])); ?> <br>


            <?php echo e(Form::textarea('frmQuestionAnser3', old('frmQuestionAnser3'),['id' => 'frmQuestionAnser3','class' => 'qtDiv','placeholder' => 'Answer 3 (optional)','rows'=>'2'])); ?> <br>


            <?php echo e(Form::textarea('frmQuestionAnser4', old('frmQuestionAnser4'),['id' => 'frmQuestionAnser4','class' => 'qtDiv','placeholder' => 'Answer 4 (optional)','rows'=>'2'])); ?> <br>

            <input type="submit" value="Launch Question" class="submitButton" style="width: 160px !important; font-size: 18px;">
        <?php echo e(Form::close()); ?>

            <p style="margin-top: 15px;"><strong>Note:</strong> The question and answers cannot be updated after clicking</p>
    </div><!-- end content -->
    
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('script'); ?>
        <script type="text/javascript">
            $(document).ready(function(){

                setTimeout(function(){  
                    $("#success").hide(); 
                }, 8000);

                $('#formQuestionInsert').validate({ // initialize the plugin  
                    /*errorPlacement: function(error, element) {
                    error.insertAfter(element.closest(".frm-error-msg"));
                    },*/
                    rules: {
                        frmQuestion: {
                            required: true,
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser1: {
                            required: true,
                            minlength: 10,
                           // maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser2: {
                            required: true,
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser3: {
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser4: {
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                    }, 
                    messages: {
                        
                    }   
                });
            });
        </script>
        
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>