    <?php $__env->startSection('title'); ?> Reset Password <?php $__env->stopSection(); ?>

    <?php $__env->startSection('style'); ?>
    <style type="text/css">
    .card {
        position: relative;
        display: flex;
        flex-direction: column;
        min-width: 0;
        word-wrap: break-word;
        background-color: #fff;
        background-clip: border-box;
        border: 1px solid rgba(0,0,0,.125);
        border-radius: .25rem;
    }
    .card>hr {
        margin-right: 0;
        margin-left: 0;
    }
    .card>.list-group:first-child .list-group-item:first-child {
        border-top-left-radius: .25rem;
        border-top-right-radius: .25rem;
    }
    .card>.list-group:last-child .list-group-item:last-child {
        border-bottom-right-radius: .25rem;
        border-bottom-left-radius: .25rem;
    }
    .card-body {
        flex: 1 1 auto;
        padding: 1.25rem;
    }
    .card-title {
        margin-bottom: .75rem;
    }
    .card-subtitle {
        margin-top: -.375rem;
    }
    .card-subtitle,.card-text:last-child {
        margin-bottom: 0;
    }
    .card-link:hover {
        text-decoration: none;
    }
    .card-link+.card-link {
        margin-left: 1.25rem;
    }
    .card-header {
        padding: .75rem 1.25rem;
        margin-bottom: 0;
        background-color: rgba(0,0,0,.03);
        border-bottom: 1px solid rgba(0,0,0,.125);
    }
    .card-header:first-child {
        border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0;
    }
    .card-header+.list-group .list-group-item:first-child {
        border-top: 0;
    }
    .card-footer {
        padding: .75rem 1.25rem;
        background-color: rgba(0,0,0,.03);
        border-top: 1px solid rgba(0,0,0,.125);
    }
    .card-footer:last-child {
        border-radius: 0 0 calc(.25rem - 1px) calc(.25rem - 1px);
    }
    .card-header-tabs {
        margin-bottom: -.75rem;
        border-bottom: 0;
    }
    .card-header-pills,.card-header-tabs {
        margin-right: -.625rem;
        margin-left: -.625rem;
    }
    .card-img-overlay {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 1.25rem;
    }
    .card-img {
        width: 100%;
        border-radius: calc(.25rem - 1px);
    }
    .card-img-top {
        width: 100%;
        border-top-left-radius: calc(.25rem - 1px);
        border-top-right-radius: calc(.25rem - 1px);
    }
    .card-img-bottom {
        width: 100%;
        border-bottom-right-radius: calc(.25rem - 1px);
        border-bottom-left-radius: calc(.25rem - 1px);
    }
    .card-deck {
        display: flex;
        flex-direction: column;
    }
    .card-deck .card {
        margin-bottom: 15px;
    }
    .form-control-plaintext {
        display: block;
        width: 100%;
        padding-top: .375rem;
        padding-bottom: .375rem;
        margin-bottom: 0;
        line-height: 1.6;
        color: #212529;
        background-color: transparent;
        border: solid transparent;
        border-width: 1px 0;
    }
    .form-control-plaintext.form-control-lg,.form-control-plaintext.form-control-sm {
        padding-right: 0;
        padding-left: 0;
    }
    .form-control-sm {
        height: calc(1.68125rem + 2px);
        padding: .25rem .5rem;
        font-size: .7875rem;
        line-height: 1.5;
        border-radius: .2rem;
    }
    .form-control-lg {
        height: calc(2.6875rem + 2px);
        padding: .5rem 1rem;
        font-size: 1.125rem;
        line-height: 1.5;
        border-radius: .3rem;
    }
    select.form-control[multiple],select.form-control[size],textarea.form-control {
        height: auto;
    }
    .form-group {
        margin-bottom: 1rem;
    }
    .form-text {
        display: block;
        margin-top: .25rem;
    }
    .form-row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -5px;
        margin-left: -5px;
    }
    .form-row>.col,.form-row>[class*=col-] {
        padding-right: 5px;
        padding-left: 5px;
    }
    .form-check {
        position: relative;
        display: block;
        padding-left: 1.25rem;
    }
    .form-check-input {
        position: absolute;
        margin-top: .3rem;
        margin-left: -1.25rem;
    }
    .form-check-input:disabled~.form-check-label {
        color: #6c757d;
    }
    .form-check-label {
        margin-bottom: 0;
    }
    .form-check-inline {
        display: inline-flex;
        align-items: center;
        padding-left: 0;
        margin-right: .75rem;
    }
    .form-check-inline .form-check-input {
        position: static;
        margin-top: 0;
        margin-right: .3125rem;
        margin-left: 0;
    }
    .valid-feedback {
        display: none;
        width: 100%;
        margin-top: .25rem;
        font-size: 80%;
        color: #38c172;
    }
    .valid-tooltip {
        position: absolute;
        top: 100%;
        z-index: 5;
        display: none;
        max-width: 100%;
        padding: .25rem .5rem;
        margin-top: .1rem;
        font-size: .7875rem;
        line-height: 1.6;
        color: #fff;
        background-color: rgba(56,193,114,.9);
        border-radius: .25rem;
    }
    .form-control {
        display: block;
        width: 100%;
        padding: .375rem .75rem;
        font-size: .9rem;
        line-height: 1.6;
        color: 
        #495057;
        background-color:
        #fff;
        background-clip: padding-box;
        border: 1px solid
        #ced4da;
        border-radius: .25rem;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }
    .text-md-right {
        text-align: right !important;
    }
    .col-form-label {
        padding-top: calc(.375rem + 1px);
        padding-bottom: calc(.375rem + 1px);
        margin-bottom: 0;
        font-size: inherit;
        line-height: 1.6;
    }
    .col-md-4 {
        flex: 0 0 33.3333333333%;
        max-width: 33.3333333333%;
    }
    .col-md-6 {
        flex: 0 0 50%;
        max-width: 50%;
    }
    .row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -15px;
        margin-left: -15px;
    }
    .col, .col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col-auto, .col-lg, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-auto, .col-md, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md-auto, .col-sm, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-auto, .col-xl, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl-auto {
        position: relative;
        width: 100%;
        min-height: 1px;
        padding-right: 15px;
        padding-left: 15px;
    }
    .offset-md-4 {
        margin-left: 33.3333333333%;
    }
    .col-md-6 {
        flex: 0 0 50%;
        max-width: 50%;
    }
    .mb-0, .my-0 {
        margin-bottom: 0 !important;
    }
    input[type="checkbox"], input[type="radio"] {
        box-sizing: border-box;
        padding: 0;
    }
    .form-check-input {
        position: absolute;
        margin-top: .3rem;
        margin-left: -1.25rem;
    }
    .col-md-8 {
        flex: 0 0 66.6666666667%;
        max-width: 66.6666666667%;
    }
    .btn:not(:disabled):not(.disabled) {
        cursor: pointer;
    }
    .btn-primary {
        color: #fff;
        background-color: #262261;
        border-color: #3490dc;
    }
    .btn {
        display: inline-block;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        border: 1px solid 
        transparent;
        border-top-color: transparent;
        border-right-color: transparent;
        border-bottom-color: transparent;
        border-left-color: transparent;
        padding: .375rem .75rem;
        font-size: .9rem;
        line-height: 1.6;
        border-radius: .25rem;
        transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }
    .btn:not(:disabled):not(.disabled) {
        cursor: pointer;
    }
    .btn-link {
        font-weight: 400;
        color: #000;
        background-color: transparent;
    }
    .btn {
        display: inline-block;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        border: 1px solid 
        transparent;
        padding: .375rem 1rem;
        font-size: .9rem;
        line-height: 1.6;
        border-radius: .25rem;
        transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
    }
    a {
        color: #3490dc;
        text-decoration: none;
        background-color: transparent;
        -webkit-text-decoration-skip: objects;
    }
    .col-md-4.col-form-label.text-md-right {
        color: #212529;
        font-weight: 400;
        font-size: 15px;
    }
    .invalid-feedback {
        color: red;
        font-size: 13px;
    }
    </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>

    <div id="content">
        <div class="qtDiv">
            <div class="card">
                <div class="card-header"><?php echo e(__('Reset Password')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('password.email')); ?>" id="frmresetpassword">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?> <span class="required">*</span></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Send Password Reset Link')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function(){

            $('#frmresetpassword').validate({ // initialize the plugin  
              /*errorPlacement: function(error, element) {
                error.insertAfter(element.closest(".frm-error-msg"));
              },*/
              rules: {
                email: {
                    required: true,
                    email: true
                }
              }, 
              messages: {
                
              }   
            });

        });
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>