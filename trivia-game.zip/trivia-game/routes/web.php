<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::get('question-detail/{id}', 'HomeController@detail_question')->name('question.details');

Route::get('your-qt-detail-page/{id}', 'HomeController@yourQuestionDetail')->name('your_qt_detail_page');

Route::post('question-flag', 'CommonController@update_flag');
Route::post('text-flag', 'CommonController@updateTextFlag');
Route::post('user-point', 'CommonController@updateUserPoints');

Route::get('about', 'HomeController@about')->name('about');
Route::get('your-questions', 'CommonController@your_questions')->name('questions');

Route::get('your-new-question', 'CommonController@your_new_question')->name('your_new_question');
Route::post('your-new-question', 'CommonController@insert_new_question');

Route::get('your-new-qt-sb/{qtid}','CommonController@yourNewQtSb')->name('your.new.qt.sb');
Route::post('your-new-qt-sb/{qtid}','CommonController@updateYourNewQtSb')->name('update.your.new.qt.sb');

Route::get('question-ans-text/{id}', 'HomeController@question_ans_text')->name('question.ans.text');
Route::get('your-qt-ans-text/{id}', 'CommonController@yourQuestionAnsText')->name('your.question.ans.text');

Route::get('your-qt-ans-text-list/{id}', 'HomeController@yourQuestionAnsTextList')->name('your.qt.ans.text.list');

Route::get('qt-ans-text-after-play/{id}', 'HomeController@qt_ans_text_after_play')->name('qt.ans.text.after.play');
Route::post('user-answer', 'CommonController@insert_user_answer');