<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserAnswer extends Model
{
    	
	public function question()
	{
		return $this->belongsTo(question::class);
	}

	public function answer()
	{
		return $this->belongsTo(Answer::class);
	}

}
