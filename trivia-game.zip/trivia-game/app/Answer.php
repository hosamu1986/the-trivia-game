<?php

namespace App;
use Auth;
use App\question;
use App\UserAnswer;
use Illuminate\Database\Eloquent\Model;

class Answer extends Model
{
    public function question()
    {
    	return $this->belongsTo(question::class);
    }

    public function answersText()
    {
    	return $this->hasMany(UserAnswer::class);
    }

    public function getSingleAnswerText($question_id,$answer_id){
    	$user_id = Auth::id();
    	return UserAnswer::where('user_id',$user_id)->where('question_id',$question_id)->where('answer_id',$answer_id)->first();
    }

}
