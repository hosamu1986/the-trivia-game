<?php
namespace App;

use App\Answer;
use Illuminate\Database\Eloquent\Model;

class question extends Model
{
    public function answers()
    {
    	return $this->hasMany(Answer::class);
    }
}
