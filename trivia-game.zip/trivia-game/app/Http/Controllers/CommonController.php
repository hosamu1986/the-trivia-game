<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\question;
use App\Answer;
use App\UserAnswer;
use App\User;
use App\UserPoint;
use App\TextFlag;
use Auth;
use App\QuestionFlag;

class CommonController extends Controller
{
    /**
     * Instantiate a new controller instance.
     * @return void
     */
    public function __construct() {
        $this->middleware('auth');
    }

    public function your_questions(){
        $user_id = Auth::user()->id;
        $data['questionResults'] = question::where('user_id',$user_id)->paginate(5);
        return view('your-question')->with($data);
    	/*return view('your-question');*/
    }

    public function your_new_question(){
        return view('your-new-question');
    }

    /**
    * Store a new question.
    * @param  Request  $request
    * @return Response
    */
    public function insert_new_question(Request $request){
        $customMessages = [
            'frmQuestion.required' => 'Question field is required.',
            'frmQuestionAnser1.required' => 'Answer 1 field is required.',             
            'frmQuestionAnser2.required' => 'Answer 2 field is required.',                              
        ];

        $this->validate($request,[
            'frmQuestion' => 'required',
            'frmQuestionAnser1' => 'required',
            'frmQuestionAnser2' => 'required',
        ],$customMessages);

        $id = Auth::user()->id;
        $question = new question;
        $question->text = $request->frmQuestion;
        $question->user_id = $id;
        $question->status = '0';
        $question->save();

        if( !empty($request->frmQuestionAnser1)){
            $answer1 = new Answer;
            $answer1->question_id = $question->id;
            $answer1->ans_number = '1';
            $answer1->ans_text = $request->frmQuestionAnser1;
            $answer1->save();
        }

        if( !empty($request->frmQuestionAnser2)){
            $answer2 = new Answer;
            $answer2->question_id = $question->id;
            $answer2->ans_number = '2';
            $answer2->ans_text = $request->frmQuestionAnser2;
            $answer2->save();
        }

        if( !empty($request->frmQuestionAnser3)){
            $answer3 = new Answer;
            $answer3->question_id = $question->id;
            $answer3->ans_number = '3';
            $answer3->ans_text = $request->frmQuestionAnser3;
            $answer3->save();
        }

        if( !empty($request->frmQuestionAnser4)){
            $answer4 = new Answer;
            $answer4->question_id = $question->id;
            $answer4->ans_number = '4';
            $answer4->ans_text = $request->frmQuestionAnser4;
            $answer4->save();
        }

        /*$success = 'New question inserted successfully.';
        \Session::flash('success', $success); 
        return redirect(route('your_new_question',$question->id));*/
        return redirect(route('your.new.qt.sb',$question->id));
    }

    public function yourNewQtSb($qtid){
        $questionModel = question::find($qtid);
        $data['questionResults'] = $questionModel;
        return view('your-new-qt-sb')->with($data);
    }

    public function updateYourNewQtSb(Request $request){
        $customMessages = [
            'frmQuestion.required' => 'Question field is required.',
            'frmQuestionAnser1.required' => 'Answer 1 field is required.',             
            'frmQuestionAnser2.required' => 'Answer 2 field is required.',                              
        ];
        $this->validate($request,[
            'frmQuestion' => 'required',
            'frmQuestionAnser1' => 'required',
            'frmQuestionAnser2' => 'required',
        ],$customMessages);

        $id = Auth::user()->id;
        $questionModel = question::find($request->frmQuestionId);
        $questionModel->text = $request->frmQuestion;
        $questionModel->user_id = $id;
        $questionModel->status = '1';
        $result = $questionModel->save();
        if($result){ 
            Answer::where('question_id',$request->frmQuestionId)->delete();
        }

        if( !empty($request->frmQuestionAnser1)){
            $answer1 = new Answer;
            $answer1->question_id = $questionModel->id;
            $answer1->ans_number = '1';
            $answer1->ans_text = $request->frmQuestionAnser1;
            $answer1->save();
        }

        if( !empty($request->frmQuestionAnser2)){
            $answer2 = new Answer;
            $answer2->question_id = $questionModel->id;
            $answer2->ans_number = '2';
            $answer2->ans_text = $request->frmQuestionAnser2;
            $answer2->save();
        }

        if( !empty($request->frmQuestionAnser3)){
            $answer3 = new Answer;
            $answer3->question_id = $questionModel->id;
            $answer3->ans_number = '3';
            $answer3->ans_text = $request->frmQuestionAnser3;
            $answer3->save();
        }

        if( !empty($request->frmQuestionAnser4)){
            $answer4 = new Answer;
            $answer4->question_id = $questionModel->id;
            $answer4->ans_number = '4';
            $answer4->ans_text = $request->frmQuestionAnser4;
            $answer4->save();
        }

        if($result){ 
            $arr = array('msg' => url('your-new-qt-sb/'.$request->frmQuestionId), 'status' => true);
            return Response()->json($arr);
        }else{
            $arr = array('msg' => 'Something goes to wrong. Please try again lator', 'status' => true);
            return Response()->json($arr);
        }
    }

    public function insert_user_answer(Request $request){
        $customMessages = [
                'frmUserAns.required' => 'Add Text field is required.',                            
        ];
        $this->validate($request,[
            'frmUserAns' => 'required',
        ],$customMessages);
        $id = Auth::user()->id;
        if (UserAnswer::where("user_id" , $id)->Where("question_id" , $request->questionID)->Where("answer_id" , $request->answerID)->count() > 0) {
            $error = 'You have already been answered.';
            \Session::flash('error', $error); 
            return redirect()->back();
        } else{
            $userAnswer = new UserAnswer;
            $userAnswer->user_id = $id;
            $userAnswer->question_id = $request->questionID;
            $userAnswer->answer_id = $request->answerID;
            $userAnswer->user_text = $request->frmUserAns;
            $userAnswer->save();

            //Adding a point to the user score.
            $user = User::find($request->userID);
            $user->points++;
            $user->save();

            //Adds 1 to the question counter.
            $question = question::find($request->questionID);
            $question->counter++;
            $question->save();

            //Adds 1 to the chosen answer.
            $answer = Answer::find($request->answerID);
            $answer->ans_counter++;
            $answer->save();

            $success = 'Add text inserted successfully.';
            \Session::flash('success', $success); 
            return redirect()->back();
        }
    }

    public function yourQuestionAnsText($id){
        $userAnswerModel = UserAnswer::find($id);
        $data['userAnswerResults'] = $userAnswerModel;
        return view('your-qt-ans-text')->with($data);
    }

    /*Question Flag Update*/
    public function update_flag(Request $request){    
        $user_id = Auth::id();
        if($request->id != ''){
            /*Check user already flaged or not*/
            $questionFlagResult = QuestionFlag::where('question_id',$request->id)->where('user_id',$user_id)->first();
            if($questionFlagResult){
                $arr = array('msg' => 'You already flaged', 'status' => true);
                return Response()->json($arr);
            }
            else{
                /*Deactivate question*/
                $questionFlagResult = new QuestionFlag;
                $questionFlagResult->user_id = $user_id;
                $questionFlagResult->question_id = $request->id;
                $questionFlagResult->flag++;
                $questionFlagResult->save();

                //Update flag.
                $question = question::find($request->id);
                $question->flag++;
                $result = $question->save();

                /*Deactivate question*/
                if ($question->flag == 3) {
                    $question->status = '0';
                    $question->save();
                }

                //Update User flag.
                $userModel = User::find($question->user_id);
                $userModel->flags++;
                $userResult = $userModel->save();

                /*Deactivate User*/
                if ($userModel->flags == 9) {
                    $userModel->status = '0';
                    $userModel->save();
                }

                if($result){ 
                    $arr = array('msg' => 'Thanks for your compliment', 'status' => true);
                    return Response()->json($arr);
                }
            }
        }
        $arr = array('msg' => 'Something goes to wrong. Please try again lator', 'status' => false);
        return Response()->json($arr);
    }

     /*Text Flag Update*/
    public function updateTextFlag(Request $request){    
        $user_id = Auth::id();
        if($request->id != ''){
            /*Check user already flaged or not*/
            $textFlagResult = TextFlag::where('user_answer_id',$request->id)->where('user_id',$user_id)->first();
            if($textFlagResult){
                $arr = array('msg' => 'You already flaged', 'status' => true);
                return Response()->json($arr);
            }
            else{
                /*Update TextFlag*/
                $textFlagModel = new TextFlag;
                $textFlagModel->user_id = $user_id;
                $textFlagModel->user_answer_id = $request->id;
                $textFlagModel->flag++;
                $textFlagModel->save();

                //Update flag.
                $userAnswerModel = UserAnswer::find($request->id);
                $userAnswerModel->flags++;
                $result = $userAnswerModel->save();

                /*Deactivate Text*/
                if ($userAnswerModel->flags == 3) {
                    $userAnswerModel->status = '0';
                    $userAnswerModel->save();
                }

                //Update User flag.
                $userModel = User::find($userAnswerModel->user_id);
                $userModel->flags++;
                $userResult = $userModel->save();

                /*Deactivate User*/
                if ($userModel->flags == 9) {
                    $userModel->status = '0';
                    $userModel->save();
                }

                if($result){ 
                    $arr = array('msg' => 'Thanks for your compliment', 'status' => true);
                    return Response()->json($arr);
                }
            }
        }
        $arr = array('msg' => 'Something goes to wrong. Please try again lator', 'status' => false);
        return Response()->json($arr);
    }

    /*Update User Points*/
    public function updateUserPoints(Request $request){    
        $user_id = Auth::id();
        if($request->id != ''){
            
            /*Check user already points or not*/
            $userPointResult = UserPoint::where('user_answer_id',$request->id)->where('user_id',$user_id)->first();
            if($userPointResult){
                $arr = array('msg' => 'Sorry, you already gave bonus points to this text.', 'status' => true);
                return Response()->json($arr);
            }
            else{
                /*Update User Points*/
                $userPointModel = new UserPoint;
                $userPointModel->user_id = $user_id;
                $userPointModel->user_answer_id = $request->id;
                $userPointModel->points = $request->points;
                $userPointModel->save();

                //Update User flag.
                $userModel = User::find($request->user_id);
                $userModel->points += $request->points;
                $userResult = $userModel->save();

                if($userResult){ 
                    $arr = array('msg' => 'Thanks for given points.', 'status' => true);
                    return Response()->json($arr);
                }
            }
        }
        $arr = array('msg' => 'Something goes to wrong. Please try again lator', 'status' => false);
        return Response()->json($arr);
    }

}
