<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\question;
use App\Answer;
use App\UserAnswer;
use App\QuestionFlag;
use Auth;
use App\User;
use App\TextFlag;

class HomeController extends Controller
{
    protected $data = array();

    /**
     * Create a new controller instance.
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $allQuestion = question::where('status','1')->paginate(5);
        $data['results'] =  $allQuestion;
        return view('home')->with($data);
    }

    public function detail_question($id){
        $results = question::find($id);
        $answers = $results->answers;
        $data['answers'] =  $answers;
        $data['results'] =  $results;
        return view('question-details')->with($data);
    }

    public function yourQuestionDetail($id){
        $results = question::find($id);
        $answers = $results->answers;
        $data['answers'] =  $answers;
        $data['results'] =  $results;
        return view('your-qt-detail-page')->with($data);
    }

    public function question_ans_text($id){
        $answerResults = Answer::find($id);
        $data['answerResults'] = $answerResults;
        $data['questionResults'] = $answerResults->question;
        $data['textResults'] = $answerResults->answersText;
        return view('question-ans-text')->with($data);
    }

    public function yourQuestionAnsTextList($id){
        $answerResults = Answer::find($id);
        $data['answerResults'] = $answerResults;
        $data['questionResults'] = $answerResults->question;
        $data['textResults'] = $answerResults->answersText;
        return view('your-qt-ans-text-list')->with($data);
    }

    public function qt_ans_text_after_play($id){
        $answerResults = Answer::find($id);
        $data['answerResults'] = $answerResults;
        $data['questionResults'] = $answerResults->question;
        return view('qt-ans-text-after-play')->with($data);
    }

    public function about() {
        return view('about');
    }
    
}
