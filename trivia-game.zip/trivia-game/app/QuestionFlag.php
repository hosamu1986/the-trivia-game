<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\question;

class QuestionFlag extends Model
{
    public function question()
    {
    	return $this->belongsTo(question::class);
    }
}
