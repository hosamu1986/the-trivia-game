
    @extends('master')
    @section('title')
        Your Questions
    @endsection

    @section('content')

    <div id="content">
        <h2 style="margin-bottom: 10px;">Your Questions</h2>
        @if( isset($questionResults) )
            @foreach ($questionResults as  $value)
                <a href="{{ route('your_qt_detail_page', $value->id)}}">
                    <div class='qtDiv'>{{ $value->text }}</div>
                </a>
            @endforeach
        @endif
    </div><!-- end content -->
    <div class="container">
        <div class="row">
            <div class="col-md-4 offset-md-9">
                {{ $questionResults->links() }}
            </div>
        </div>
    </div>

    @endsection
