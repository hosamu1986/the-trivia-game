
    @extends('master')
    @section('title')
        New Question & Answers
    @endsection

    @section('style')
        <style type="text/css">
            .qtDiv{ padding: 10px; }
            .alert.alert-danger li {list-style: none; }
        </style>
    @endsection

    @section('content')

    <div id="content">
        <h2>New Question &amp; Answers</h2>
            You must enter at least two answers<br /><br>

        @if(Session::has('success'))
        <div class="row" id="success">
            <div class="col-md-6 offset-md-3">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert">×</a>
                    {!!Session::get('success')!!}
                </div>
            </div>
        </div>
        @endif
        @if ($errors->any())
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div><br />
                </div>
            </div> 
        @endif

        {{ Form::open(array('url' => 'your-new-question','method' => 'post','class'=>'form-inner','id'=>'formQuestionInsert', 'enctype'=>'multipart/form-data' )) }}

            {{ Form::textarea('frmQuestion', old('frmQuestion'),['id' => 'frmQuestion','class' => 'qtDiv','placeholder' => 'Your Question','rows'=>'2']) }} <br>

            {{ Form::textarea('frmQuestionAnser1', old('frmQuestionAnser1'),['id' => 'frmQuestionAnser1','class' => 'qtDiv','placeholder' => 'Answer 1','rows'=>'2']) }} <br>


            {{ Form::textarea('frmQuestionAnser2', old('frmQuestionAnser2'),['id' => 'frmQuestionAnser2','class' => 'qtDiv','placeholder' => 'Answer 2','rows'=>'2']) }} <br>


            {{ Form::textarea('frmQuestionAnser3', old('frmQuestionAnser3'),['id' => 'frmQuestionAnser3','class' => 'qtDiv','placeholder' => 'Answer 3 (optional)','rows'=>'2']) }} <br>


            {{ Form::textarea('frmQuestionAnser4', old('frmQuestionAnser4'),['id' => 'frmQuestionAnser4','class' => 'qtDiv','placeholder' => 'Answer 4 (optional)','rows'=>'2']) }} <br>

            <input type="submit" value="Launch Question" class="submitButton" style="width: 160px !important; font-size: 18px;">
        {{ Form::close() }}
            <p style="margin-top: 15px;"><strong>Note:</strong> The question and answers cannot be updated after clicking</p>
    </div><!-- end content -->
    
    @endsection

    @section('script')
        <script type="text/javascript">
            $(document).ready(function(){

                setTimeout(function(){  
                    $("#success").hide(); 
                }, 8000);

                $('#formQuestionInsert').validate({ // initialize the plugin  
                    /*errorPlacement: function(error, element) {
                    error.insertAfter(element.closest(".frm-error-msg"));
                    },*/
                    rules: {
                        frmQuestion: {
                            required: true,
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser1: {
                            required: true,
                            minlength: 10,
                           // maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser2: {
                            required: true,
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser3: {
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                        frmQuestionAnser4: {
                            minlength: 10,
                            //maxlength: 500,
                            //lettersonly: true,
                        },
                    }, 
                    messages: {
                        
                    }   
                });
            });
        </script>
        
    @endsection