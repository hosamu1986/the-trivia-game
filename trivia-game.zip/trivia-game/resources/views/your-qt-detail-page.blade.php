
    @extends('master')
    @section('title')
        Question Details
    @endsection

    @section('content')
        <div id="content">
            <!-- success message -->
            <div class="row" style="width: 90%;">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" style="display:none"></div>
                    <div class="alert alert-success d-none" id="msg_div">
                        <span id="res_message"></span>
                    </div>
                </div>
            </div>

            <div class='qtDiv'>
                <div class="qtDate">{{$results->created_at->format('m/d/y')}}</div>
                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <p style="margin-bottom: 30px;margin-top: 40px; font-weight: bold;">{{ $results->text }}</p>
                @if( isset($answers) )
                    @foreach ($answers as  $value)
                        <div class='ansDiv'>
                            <div class='ansLeftCol'><div class='ansNumber'>{{ $value->ans_number }}</div>19%</div>
                            <div class='ansText'>
                                <a href="{{route('your.qt.ans.text.list',$value->id)}}">
                                    {{ $value->ans_text }}
                                </a>
                            </div>
                        </div>
                    @endforeach
                @endif
                <a href="{{route('questions')}}">
                    <div class='rerunQT'>Rerun Question</div>
                </a>
            </div>
        </div><!-- end content -->
        
    @endsection
    @section('script')
        <script type="text/javascript">
            $(document).ready(function(){
                $("#red-flag").click(function(){
                    $('#msg_div').addClass('d-none');
                    $('#msg_div').show();
                    var questionId = $(this).attr("data-id");
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url:"{{url('question-flag')}}",  
                        method:"POST", 
                        data: { id: questionId },
                        success: function(response)
                        {
                            console.log(response);
                            //$('#something').html(response);
                            $('#res_message').show();
                            $('#res_message').html(response.msg);
                            $('#msg_div').removeClass('d-none');
                            setTimeout(function(){
                                $('#res_message').hide();
                                $('#msg_div').hide();
                            },3000);
                            jQuery.each(response.errors, function(key, value){
                                $('#msg_div').hide();
                                $('.alert-danger').show();
                                $('.alert-danger').append('<p>'+value+'</p>');
                            });
                        }
                    });
                });
            });
        </script>
    @endsection