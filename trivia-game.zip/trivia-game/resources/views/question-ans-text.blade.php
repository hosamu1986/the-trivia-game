
    @extends('master')
    @section('title')
        Question Ans Details
    @endsection

    @section('content')


        <div id="content">
            <!-- success message -->
            <div class="row" style="width: 90%;">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" style="display:none"></div>
                    <div class="alert alert-success d-none" id="msg_div">
                        <span id="res_message"></span>
                    </div>
                </div>
            </div>

            <div class='qtDiv'>

                <div class="qtDate">{{$answerResults->created_at->format('m/d/y')}} <!-- 8/19/19  --></div>

                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <br>

                <p style="margin-bottom: 30px;margin-top: 15px; font-weight: bold;">
                    {{ $questionResults->text }}
                </p>

                <div class='ansDiv'>
                    <div class='ansLeftCol'><div class='ansNumber'>{{ $answerResults->ans_number }}</div>19%</div>
                    <div class='ansText'>{{ $answerResults->ans_text }}</div>
                </div>

                <div class="ansTexts">

                    @if( isset($textResults) )
                        @foreach ($textResults as  $value)
                            <div class="textOfAns">
                                {{$value->user_text}} <br>
                                @if (!Auth::guest())
                                    @if($value->user_id == Auth::id())
                                        <a href="javascript:;">
                                            <img src="{{ asset('images/red-flag.png') }}" width="18" height="18" alt=""/>
                                        </a>
                                    @else
                                        <a href="javascript:;" data-id="{{ $value->id }}" id="red-flag">
                                            <img src="{{ asset('images/red-flag.png') }}" width="18" height="18" alt=""/>
                                        </a>
                                    @endif
                                @else
                                    <a href="javascript:;">
                                        <img src="{{ asset('images/red-flag.png') }}" width="18" height="18" alt=""/>
                                    </a>
                                @endif

                            </div>
                        @endforeach
                    @endif





                    <!-- <div class="textOfAns">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<Br>
                    <a href="#"><img src="{{ asset('images/red-flag.png') }}" width="18" height="18" alt=""/></a>
                    </div>

                    <div class="textOfAns">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br>
                    <a href="#"><img src="{{ asset('images/red-flag.png') }}" width="18" height="18" alt=""/></a>
                    </div>

                    <div class="textOfAns">
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<Br>
                    Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br>
                    <a href="#"><img src="{{ asset('images/red-flag.png') }}" width="18" height="18" alt=""/></a>
                    </div> -->

                </div>
            </div>

        </div><!-- end content -->


        <!--  -->
        
    @endsection
    @section('script')
        <script type="text/javascript">
            $(document).ready(function(){
                $("#red-flag").click(function(){
                    $('#msg_div').addClass('d-none');
                    $('#msg_div').show();
                    var questionId = $(this).attr("data-id");
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url:"{{url('text-flag')}}",  
                        method:"POST", 
                        data: { id: questionId },
                        success: function(response)
                        {
                            console.log(response);
                            //$('#something').html(response);
                            $('#res_message').show();
                            $('#res_message').html(response.msg);
                            $('#msg_div').removeClass('d-none');
                            setTimeout(function(){
                                $('#res_message').hide();
                                $('#msg_div').hide();
                            },3000);
                            jQuery.each(response.errors, function(key, value){
                                $('#msg_div').hide();
                                $('.alert-danger').show();
                                $('.alert-danger').append('<p>'+value+'</p>');
                            });
                        }
                    });
                });
            });
        </script>
    @endsection