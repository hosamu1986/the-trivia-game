    @extends('master')
    @section('title')
        Question Ans Text After Play
    @endsection

    @section('content')

        <div id="content">

            @if(Session::has('success'))
            <div class="row" id="success">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-success">
                        <a class="close" data-dismiss="alert">×</a>
                        {!!Session::get('success')!!}
                    </div>
                </div>
            </div>
            @endif

            @if(Session::has('error'))
            <div class="row" id="success">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger" role="alert">
                        <a class="close" data-dismiss="alert">×</a>
                        {!!Session::get('error')!!}
                    </div>
                </div>
            </div>
            @endif

            <div class='qtDiv'>

                <div class="qtDate">{{$answerResults->created_at->format('m/d/y')}} </div>

                <div class="qtCounter">Volume: </div>
                <div id="validity-bar">
                    <div id="validity-presentage">50%</div>
                </div>
                <br>

                <p style="margin-bottom: 30px;margin-top: 15px; font-weight: bold;">
                    {{ $questionResults->text }}
                </p>

                <div class='ansDiv'>
                    <div class='ansLeftCol'><div class='ansNumber'>{{ $answerResults->ans_number }}</div>19%</div>
                    <div class='ansText'>{{ $answerResults->ans_text }}</div>
                </div>

                {{ Form::open(array('url' => 'user-answer','method' => 'post','class'=>'form-inner','id'=>'formAnswerInsert', 'enctype'=>'multipart/form-data' )) }}

                    @if( Auth::user()->id == $questionResults->user_id  )
                        <textarea  id="frmUserAns" class="inputFieldText" placeholder="Add Text" name="frmUserAns" cols="50" rows="10" disabled></textarea>
                    @else
                        {{ Form::textarea('frmUserAns', old('frmUserAns'),['id' => 'frmUserAns','class' => 'inputFieldText','placeholder' => 'Add Text']) }}<br>
                    @endif  

                    @if ($errors->has('frmUserAns'))
                        <span class="invalid-feedback" role="alert" style="display:block;">
                            <strong>{{ $errors->first('frmUserAns') }}</strong>
                        </span> <br/>
                    @endif

                    <input type="hidden" name="questionID" value="{{ $questionResults->id }}">
                    <input type="hidden" name="answerID" value="{{ $answerResults->id }}">
                    <input type="hidden" name="userID" value="{{ $questionResults->user_id }}">

                    <input type="submit" value="SAVE" class="submitButton" style="border: none; font-size: 18px;"  {{ ( Auth::user()->id == $questionResults->user_id  ) ? 'disabled' : ''}}/>
               {{ Form::close() }}
                
            </div>

        </div><!-- end content -->
        
    @endsection

    @section('script')
        <script type="text/javascript">
            $(document).ready(function(){

                setTimeout(function(){  
                    $("#success").hide(); 
                }, 8000);

                $('#formAnswerInsert').validate({ 
                    rules: {
                        frmUserAns: {
                            required: true,
                            minlength: 10,
                            maxlength: 500,
                            //lettersonly: true,
                        },
                    }, 
                    messages: {
                        
                    }   
                });

            });
        </script>        
    @endsection