	<header>
		<div class="profileLogo" style="margin-bottom: 15px; margin-top: 15px;"> 
			<!-- Profile logo. Add a img tag in place of <span>. -->
			<p class="logoPlaceholder">
				<a href="{{ url('/') }}">
					<img src="{{ asset('images/theTriviaGame-logo.png') }}" width="416" height="74" alt=""/>
				</a>
			</p>
		</div>
	
		<div class="row">
			<div class="col-md-8 offset-md-1 pl-0 pr-0">
				<div class="row">
						<div class="col-md-8 pr-0 pl-5">
							
							@guest
							<div class="row">
								<div class="col-md-8 pr-0">
								{{ Form::open(array('url' => 'login','method' => 'post','class'=>'form-inner','id'=>'frmlogin', 'enctype'=>'multipart/form-data' )) }} 
									<input id="login" type="text" class="inputField {{ $errors->has('username') || $errors->has('email') ? ' is-invalid' : '' }}" name="login" value="{{ old('username') ?: old('email') }}" placeholder="username" required autofocus />
									
		                            <input id="password" type="password" class="inputField {{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="password" required>
		                            @if ($errors->has('password'))
		                                <span class="invalid-feedback" role="alert">
		                                    <strong>{{ $errors->first('password') }}</strong>
		                                </span>
		                            @endif
		                            <input type="submit" name="submit" style="display: none;" />
								{{ Form::close() }}

								</div>
								<div class="col-md-4 pl-0 text-left">
						            <a href="{{ route('register') }}" style="font-size: 13px; color: #000;">Sign in</a> /
									<a href="{{ route('login') }}" style="font-size: 13px; color: #000;">Login</a> /
								</div>
							</div>
					        @else
					            <span style="font-size: 18px;"><strong>Hi {{ Auth::user()->username }}  <!-- {{ Auth::user()->created_at->toTimeString()}} --></strong>,</span> &nbsp;&nbsp;&nbsp;&nbsp;
				                <a style="font-size: 13px; color: #000;" href="{{ route('logout') }}"onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
				                    {{ __('Logout') }}
				                </a>
				                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
				                    @csrf
				                </form>
					        @endguest
					        
				       	</div>
			        	<div class="col-md-4 pl-0 text-left">
			        		@php $currentRouteName = Route::currentRouteName(); @endphp
			        		@if( $currentRouteName == 'questions' )
			        			Your Ranking: <strong>{{Auth::user()->points}}</strong>&nbsp;/
			        		@else
			        			@if (!Auth::guest())
				        			<a href="{{route('questions')}}" style="font-size: 14px; color: #000;">Your Questions</a>&nbsp;/
				        		@endif
			        		@endif
			        		
							<a href="{{ url('about') }}" style="font-size: 13px; color: #000;">About</a> &nbsp;/&nbsp; 
							<a href="#"> <img src="{{ asset('images/Search-20.png') }}" style="width: 16px; height: auto;" alt=""/> </a>
						</div>
						<div class="col-md-12 offset-md-2 text-left">
							@if ($errors->has('username') || $errors->has('email'))
                                <span class="invalid-feedback" role="alert" style="display: block;">
                                    <strong>{{ $errors->first('username') ?: $errors->first('email') }}</strong>
                                </span>
                            @endif
                        </div>
				</div>	
			</div>
		</div>

	</header>