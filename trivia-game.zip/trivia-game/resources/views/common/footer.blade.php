	<footer>
		<div class="footerContent">
			<!--<form name="bottomSearch" method="post" action="">
			<input type="image" src="images/search-pic.jpg" class="footerSearchIcon" />
			<input type="text" name="bottom-search" class="footerSearch" placeholder="Search questions by keywords" />
			</form>-->
			<!--<a href="whatisallabout.php" class="blueLink">What's it all about</a><Br>-->
		</div>
		<div id="footerbuttons">
			@php $currentRouteName = Route::currentRouteName(); @endphp
			@guest
        		@if( $currentRouteName == 'question.details' )
				<p id="footerErrorMessage" style="font-weight: bold; color: red; font-size: 18px; margin-top: 0px; margin-bottom: 5px;">Sign in / Log in to PLAY</p>
				@endif
			@else
				<p id="footerErrorMessage" style="font-weight: bold; color: red; font-size: 18px; margin-top: 0px; margin-bottom: 5px; display: none;">You must Sign in / Log in first</p>
			@endif

			@if( $currentRouteName == 'your.qt.ans.text.list' )
				<p style="font-weight: bold; color: red; font-size: 16px; margin-top: 0px; margin-bottom: 5px;">Note: Choose text to give bonus points</p>
			@endif

			<a href="{{ route('home') }}">
				<div class="footerleftButton">
					<div class="footeryour2cents">You Play</div>
					<p style="font-weight: bold; margin-top:  5px;">Play trivia game</p>
				</div>
			</a>

			@guest
				<div class="footerrightButton" id="footerrightButton">
					<div class="footerask">Your Trivia</div>
					<p style="font-weight: bold; margin-top:  5px;">Create trivia</p>
				</div>
			@else
				<a href="{{ route('your_new_question') }}">
					<div class="footerrightButton">
						<div class="footerask">Your Trivia</div>
						<p style="font-weight: bold; margin-top:  5px;">Create trivia</p>
					</div>
				</a>
			@endif
			

		</div>
	</footer><!-- end of footer -->