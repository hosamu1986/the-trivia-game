
    @extends('master')
    @section('title')
        New Question & Answers
    @endsection

    @section('style')
        <style type="text/css">
            .qtDiv{ padding: 10px; }
            .alert.alert-danger li {list-style: none; }
        </style>
    @endsection

    @section('content')

    <div id="content">
        <h2>New Question &amp; Answers</h2>
            You must enter at least two answers<br /><br>

        @if(Session::has('success'))
        <div class="row" id="success">
            <div class="col-md-6 offset-md-3">
                <div class="alert alert-success">
                    <a class="close" data-dismiss="alert">×</a>
                    {!!Session::get('success')!!}
                </div>
            </div>
        </div>
        @endif
        @if ($errors->any())
            <div class="row">
                <div class="col-md-6 offset-md-3">
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div><br />
                </div>
            </div> 
        @endif

        {{ Form::open(array('route' => ['update.your.new.qt.sb',$questionResults->id],'method' => 'post','class'=>'form-inner','id'=>'formQuestionInsert','name'=>'formQuestionInsert' )) }}
            {{ Form::hidden('frmQuestionId', @$questionResults->id,['id' => 'frmQuestionId','class' => 'qtDiv']) }}
            {{ Form::textarea('frmQuestion', @$questionResults->text,['id' => 'frmQuestion','class' => 'qtDiv','placeholder' => 'Your Question','rows'=>'2']) }} <br>
            {{ Form::textarea('frmQuestionAnser1', @$questionResults->answers[0]->ans_text,['id' => 'frmQuestionAnser1','class' => 'qtDiv','placeholder' => 'Answer 1','rows'=>'2']) }} <br>
            {{ Form::textarea('frmQuestionAnser2', @$questionResults->answers[1]->ans_text,['id' => 'frmQuestionAnser2','class' => 'qtDiv','placeholder' => 'Answer 2','rows'=>'2']) }} <br>
            {{ Form::textarea('frmQuestionAnser3', @$questionResults->answers[2]->ans_text,['id' => 'frmQuestionAnser3','class' => 'qtDiv','placeholder' => 'Answer 3 (optional)','rows'=>'2']) }} <br>
            {{ Form::textarea('frmQuestionAnser4', @$questionResults->answers[3]->ans_text,['id' => 'frmQuestionAnser4','class' => 'qtDiv','placeholder' => 'Answer 4 (optional)','rows'=>'2']) }} <br>
            <input type="submit" value="Save your trivia" class="submitButton" style="width: 160px !important; font-size: 18px;">
        {{ Form::close() }}

        <div id="snowball" class="pop-up-div-ex3" style="display:none; z-index:100;" >
            <input type="button" class="closeSquare" value="X" onclick="$('#snowball').fadeOut('slow')" />
            <h2>Save your trivia</h2>
            <p> Save your trivia question on<br> Your computer<br> Get your internet address<br> For this question<Br> (URL) </p>
            <p><a href="javascript:;" id="qturl">http://the-trivia-game.com/id=2033</a></p>
            <!-- <input type="submit" value="Copy text and link" class="submitButton" style="width: 151px !important;"> -->
            <input type="submit" value="Copy text and link" id="submitButton" class="submitButton" style="width: 151px !important;">
        </div>

        <p style="margin-top: 15px;"><strong>Note:</strong>  Save the internet link of your trivia question. You never know…</p>
    </div><!-- end content -->
    
    @endsection

    @section('script')
        <script src="{{asset('js/jquery.copy-to-clipboard.js')}}"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('#submitButton').click(function(){
                    $("#qturl").CopyToClipboard();
                });
                setTimeout(function(){  
                    $("#success").hide(); 
                }, 8000);

                $('#formQuestionInsert').validate({ 
                    rules: {
                        frmQuestion: {
                            required: true,
                            minlength: 10,
                        },
                        frmQuestionAnser1: {
                            required: true,
                            minlength: 10,
                        },
                        frmQuestionAnser2: {
                            required: true,
                            minlength: 10,
                        },
                        frmQuestionAnser3: {
                            minlength: 10,
                        },
                        frmQuestionAnser4: {
                            minlength: 10,
                        },
                    }, 
                    messages: {
                        
                    },
                   submitHandler: function(form) {
                        $.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            }
                        });
                        $.ajax({
                            url:"{{route('update.your.new.qt.sb',$questionResults->id)}}",  
                            method:"POST", 
                            data: $('form').serialize(),
                            success: function(response)
                            {
                                $("#snowball").show();
                                $('#qturl').text(response.msg);
                            }
                        });
                    } 
                });
            });
        </script>
        
    @endsection