
    @extends('master')
    @section('title')
        Home
    @endsection

    @section('content')

        <div id="content">
            @foreach ($results as $result)
                <a href="{{route('question.details',$result->id)}}"> <div class='qtDiv'> {{ $result->text }} </div></a>
            @endforeach
        </div><!-- end content -->
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-9">
                    {{ $results->links() }}
                </div>
            </div>
        </div>
    @endsection
